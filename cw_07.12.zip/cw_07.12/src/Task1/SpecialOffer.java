package Task1;

public class SpecialOffer {
}
