package Task2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class FictionBook extends AbstractBook{
    Scanner scn = new Scanner(System.in);

    @Override
    public void addToCatalog(Book[] books) {
        ArrayList<Book> newBooks = new ArrayList<>(Arrays.asList(books));
        System.out.println("Enter all");
        String title = scn.next();
        String author = scn.next();
        int year = scn.nextInt();
        newBooks.add(books[books.length - 1] = new Book(title, author, year));
        System.out.println(newBooks);
    }

    @Override
    void removeFromCatalog(Book[] books) {
    }

    void calculatePopularity(Book[] books){
    }
    void applyDiscount(Book[] books, double discount){
    }
}
////FictionBook (наследует AbstractBook):
////Методы:
////calculatePopularity(Book[] books): Вычисление популярности.
////applyDiscount(Book[] books, double discount): Применение скидки.
