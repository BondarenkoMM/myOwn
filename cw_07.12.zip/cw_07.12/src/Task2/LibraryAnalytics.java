package Task2;

//LibraryAnalytics (реализует ICatalogManagement):
//Методы:
//calculateAverageRating(Book[] books): Вычисление средней оценки книг.
//findLeastReadBooks(Book[] books): Поиск наименее читаемых книг.
class LibraryAnalytics implements ICatalogManagement{
    void calculateAverageRating(Book[] books){
    }
    void findLeastReadBooks(Book[] books){
    }
}
