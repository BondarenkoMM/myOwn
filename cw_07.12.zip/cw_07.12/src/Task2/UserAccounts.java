package Task2;

//UserAccounts (наследует AbstractUser, реализует IUserManagement):
//Методы:
//updateAccount(User user, AccountDetails details): Обновление учетной записи.
//trackUserHistory(User user): Отслеживание истории пользователя.
class UserAccounts extends AbstractUser implements  IUserManagement{
    @Override
    void borrowBook(Book[] books) {
    }

    @Override
    void returnBook(Book[] books) {
    }
    void updateAccount(User user, AccountDetails details){

    }
}
