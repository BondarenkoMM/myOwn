package Task2;

//BookReview (наследует FictionBook):
//Методы:
//addReview(Book[] books, Review review): Добавление отзыва.
//listReviews(Book[] books): Список отзывов.
class BookReview extends FictionBook{
    void addReview(Book[] books, Review review){
    }
    void listReviews(Book[] books){
    }
}
