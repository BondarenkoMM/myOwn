package Task2;

public class User {
}
