package Task2;

//ReferenceBook (наследует NonFictionBook):
//Методы:
//listReferences(Book[] books): Список ссылок.
//updateReferences(Book[] books, Reference[] newReferences): Обновление списка ссылок.
class ReferenceBook extends NonFictionBook{
    void listReferences(Book[] books){
    }
    void updateReferences(Book[] books, Reference[] newReferences){
    }
}
