package Task2;

//NonFictionBook (наследует AbstractBook):
//Методы:
//updateInformation(Book[] books, String newInfo): Обновление информации о книге.
//listRelatedBooks(Book[] books, String topic): Список книг по теме.
class NonFictionBook extends AbstractBook{
    @Override
    void addToCatalog(Book[] books) {
    }

    @Override
    void removeFromCatalog(Book[] books) {
    }
    void updateInformation(Book[] books, String newInfo){
    }
    void listRelatedBooks(Book[] books, String topic){
    }
}