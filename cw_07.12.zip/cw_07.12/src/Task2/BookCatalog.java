package Task2;

//BookCatalog (реализует ICatalogManagement):
//Методы:
//listNewArrivals(Book[] books): Список новых поступлений.
//listMostBorrowedBooks(Book[] books): Список наиболее взятых книг.
class BookCatalog implements ICatalogManagement{
    void listNewArrivals(Book[] books){
    }
    void listMostBorrowedBooks(Book[] books){
    }
}