package Task2;

//Ebook (наследует FictionBook):
//Методы:
//downloadBook(Book[] books): Скачивание книги.
//updateEbookFormat(Book[] books, String format): Обновление формата электронной книги.
class Ebook extends FictionBook{
    void downloadBook(Book[] books){
    }
    void updateEbookFormat(Book[] books, String format){
    }
}
