import Task2.Book;
import Task2.FictionBook;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        Book[] books = {
                new Book("Мастер и Маргарита", "Михаил Булгаков", 1999),
                new Book("Преступление и наказание", "Федор Достоевский", 1999)
        };
    }
}