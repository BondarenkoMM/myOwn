interface Playable{
    public void play(String trackName);
    public void stop();
    public String getCurrentTrack();
}