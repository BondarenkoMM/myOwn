interface Recordable{
    public void record();
    public void stopRecording();
}