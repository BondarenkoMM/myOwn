package org.example._2023_12_07;

public class Ter {

    @Override
    public int hashCode() {
        return 0;
    }

    public static void main(String[] args) {
        System.out.println(new Ter().hashCode());
    }
}
