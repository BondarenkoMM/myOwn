package org.example._2023_12_07.i;

public class TEst {
    public static void main(String[] args) {
    }
}
