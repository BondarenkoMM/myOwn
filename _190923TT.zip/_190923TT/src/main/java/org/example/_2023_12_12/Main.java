package org.example._2023_12_12;

import org.example._2023_12_12.tE.Account;
import org.example._2023_12_12.tE.Generator;
import org.example._2023_12_12.tE.Handler;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Account[] account = Generator.accountGenerator(5);
        System.out.println(Arrays.toString(account));
        Handler handler = new Handler();
        System.out.println(handler.sumBalances(account));
    }

}
