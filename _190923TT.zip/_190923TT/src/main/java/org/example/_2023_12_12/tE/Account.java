package org.example._2023_12_12.tE;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@Getter
@Setter
@ToString
public class Account {

    private String accountNumber;
    private Country country;
    private Currency currency;
    private boolean isDebit;
    private double balance;

    public Account(String accountNumber, Country country, Currency currency, boolean isDebit, double balance) {
        this.accountNumber = accountNumber;
        this.country = country;
        this.currency = currency;
        this.isDebit = isDebit;
        this.balance = balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        if (accountNumber == null){
            System.out.println("Can`t be null.");
        } else {
            this.accountNumber = accountNumber;
        }
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}

class Bank {
    Branch[] branches;

    public Branch[] getBranches() {
        return branches;
    }

    public void setBranches(Branch[] branches) {
        this.branches = branches;
    }
}

class Branch {
    Empl[] employees;

    public Empl[] getEmployees() {
        return employees;
    }

    public void setEmployees(Empl[] employees) {
        this.employees = employees;
    }
}

class Empl {
    private String name;
    private String surName;
    private Account[] account;

    private Citezeship citizenship;
}

enum Country {
    GERMANY,
    POLAND,
    FRANCE,
    USA,
    UK
}

enum Currency {
    EURO,
    ZLOTY,
    FUNT,
    DOLLAR

}

enum Citezeship {
    GERMANY,
    POLAND,
    FRANCE,
    USA,
    UK
}

