package org.example._2023_12_12.tE;

import com.github.javafaker.Faker;
import lombok.ToString;
import lombok.experimental.UtilityClass;

import java.math.BigDecimal;
import java.util.Random;

@UtilityClass
public class Generator {
    private static final Faker FAKER = new Faker();
    private static final Random RANDOM = new Random();

    public String generateAccNum(){
        return String.valueOf(FAKER.idNumber());
    }
    Country generateCountry(){
        int currCountry = RANDOM.nextInt(5);
        return switch(currCountry){
            case 0 -> Country.GERMANY;
            case 1 -> Country.POLAND;
            case 2 -> Country.FRANCE;
            case 3 -> Country.USA;
            default -> Country.UK;
        };
    }
    Currency generateCurrency(){
        return switch (generateCountry()){
            case GERMANY -> Currency.EURO;
            case POLAND -> Currency.ZLOTY;
            case FRANCE -> Currency.EURO;
            case USA -> Currency.DOLLAR;
            case UK -> Currency.FUNT;
        };
    }
    boolean IsDebitGenerate(){
        return switch (RANDOM.nextInt(2)){
            case 0 -> true;
            default -> false;
        };
    }
    double generateBalance(){
        return RANDOM.nextInt(20001) + RANDOM.nextDouble();
    }

    public static Account[] accountGenerator (int arrLength){
        Account[] account = new Account[arrLength];
        for (int i = 0; i < arrLength; i++) {
            account[i] = new Account(
                              generateAccNum(),
                              generateCountry(),
                              generateCurrency(),
                              IsDebitGenerate(),
                              generateBalance()
            );
        }
        return account;
    }

}
