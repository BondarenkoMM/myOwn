package org.example._2023_12_08;

public enum Condition {
    NEW,
    OLD,
    DAMAGED
}