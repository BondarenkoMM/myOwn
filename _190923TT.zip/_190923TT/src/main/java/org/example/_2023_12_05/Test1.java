package org.example._2023_12_05;

import java.util.ArrayList;
import java.util.List;

public class Test1 {
    String s;
    int[] arr = new int[10];
    int[] arr1 = {12, 3, 4, 5, 67, 89};

    public static void main(String[] args) {
        Test1 te = new Test1();
        int a = 5; // x + y == 10, x == 6
        System.out.println(a);
        List<Integer> list = new ArrayList<>();

    }

}

class Postman {
    public boolean isArrived(Post post) {
        return true;
    }
}

class Post {

}