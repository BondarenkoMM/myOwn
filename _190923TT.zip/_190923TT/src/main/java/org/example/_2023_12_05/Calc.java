package org.example._2023_12_05;

public class Calc {
    public int sum(int a, int b) {
        return a + b;
    }

    public int minus(int a, int b) {
        return a - b;
    }

    public static void main(String[] args) {

//        sum(sum(12, sum(12, 3)), minus(22, minus(22, 11)));
//
//        int r1 = minus(10, 6);
//        int r2 = minus(13, 4);
//
//        sum(minus(10, minus(13, 4)), minus(minus(13, 4), 4));
    }
}