package org.example._05_12_2023;

public class Test1 {
    int getSum(int[] arr) {
        int sum = 0;
        int start = 0;
        int end = arr.length - 1;
        while(start > end){
            sum += arr[start] + arr[end];
        }
        return sum;
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 4, 6, 4, 7};
        System.out.println(new Test1().getSum(arr));
    }
}
